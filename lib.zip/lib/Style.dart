import 'package:flutter/material.dart';

Color orenge = new Color(0xFFF3B67D);
Color brown = new Color(0xFFC98F59);
Color black = new Color(0xff4d4d4d);
Color cream = new Color(0xFFE6C594);